# Changelog

本文件记录 dsh-opencode-go 的显著变更。格式参考 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [Unreleased]

## [0.7.3] - 2026-11-26

### Added

- 多账号轮询会参考各账号的月度剩余额度：新会话先挑剩余更多的账号，一周内就要刷新的额度优先用掉，避免额度到期作废。只有领先 30 个百分点以上才改变顺序，差距不大时仍按原来的轮换，保护会话缓存。
- 额度数据由插件在后台刷新（每个账号最多 5 分钟一次），超过 15 分钟、读取失败或数据不全时自动回到普通轮换。

## [0.7.2] - 2026-11-26

### Fixed

- 手动「设为当前」或更换某个账号的 Key 后，正在进行的会话会在下一轮改用这个账号，不再继续停留在旧账号上；同时清除该账号之前的冷却记录，换了 Key 或改好区域限制后不必等冷却结束。
- 手动选号会把轮询起点重置到所选账号，新会话也不会立刻又轮回到别的账号。

## [0.7.1] - 2026-11-26

### Added

- 新增 `REGION_RESTRICTED` 错误码：识别网关返回的「This OpenCode Go model is hosted outside Europe and the United States. Select Global at …」区域限制 400，与额度耗尽一样换到下一个账号，并在用量胶囊中提示「当前账号所在区域不支持该模型，已自动切换为：…」。

### Changed

- 打开多账号轮询（`balanceAccounts`）时视同允许故障切换：额度耗尽、限流、Key 失效或区域限制会在当前请求内换到下一个账号；轮询仍不写回列表顺序和当前账号。
- 额度耗尽与区域限制的账号冷却由 5 分钟延长到 1 小时（新增 `UNAVAILABLE_KEY_TTL_MS`），避免对整月额度已用光或区域不支持的账号每 5 分钟重试；凭证失效仍冷却 5 分钟，限流仍按 Retry-After（默认 15 秒，1 秒–5 分钟）。

## [0.7.0] - 2026-11-26

### Added

- 合入上游 0.4.6 → 0.5.1：
  - 配额月度告警、瓶颈窗口透出与三档使用画像（轻度问答 / 标准编码 / 长上下文 Agent）的满额请求数估算；账号可单独选择 Go ($10) / Go Plus ($40) / Go Teams ($20) 套餐档位，仅用于本地换算，不影响上游计费。
  - 高级设置新增无密钥 `/models` 网关与代理连通性探测、毫秒 / 字节 / 像素 / 分钟字段的人类可读换算提示与单项恢复默认，控制台页签在存在未保存草稿时显示脏点。
  - 模型页新增按额度倍率 / 上下文窗口 / 发布时间的排序、已开启与已关闭筛选、一键全部开启 / 全部关闭（带受影响计数与撤销）、思考预算快捷芯片、三态输入模态标识与网关价格明细。
  - 账号卡片支持整行展开与多行对比、一键设为当前、添加表单内置套餐选择器与 Key 显隐，输入栏切号弹层异步预览各账号额度。
  - 外观页重组为三组 Bento 主题预览与 3×2 胶囊实景沙盒；概览页重做信息架构（今日 KPI、账号回退链、0 账号引导、可点击固定的 7 日柱图）；关于页新增脱敏诊断摘要复制。
  - 用量看板新增「用量金额」趋势维度、可点击图例、缓存命中率列、粘性首列与导出反馈。
  - 会话模型选择器与模型列表实时显示额度消耗倍率（`showModelMultiplier`，默认开启）；Go 路由新增 `retryPolicy`（默认标准模式、5 次重试、30 秒最大退避）。
  - 上游 0.5.0 / 0.5.1 的完整条目保留在本文件下方「upstream 0.5.0」「upstream 0.5.1」两节。

### Changed

- 插件包图标由位图 `assets/icon.png` 改为矢量 `assets/icon.svg`，并新增 npm Trusted Publishing 发布 workflow。
- 仓库根目录继续只跟踪一个预打包归档，本版为 `dsh-opencode-go-0.7.0.tgz`；上游的 `dsh-opencode-go-0.5.1.tgz` 已删除。

### Fixed

- 修复 Go 通道经 SOCKS5 代理访问 IPv6 字面量代理地址时全部请求失败（`network error (ENOTFOUND)`，#121）。
- 修复普通 HTTP 429 请求限流被误判为额度耗尽并改写主备账号顺序（#113、#114）、额度倍率插槽与其他插件优先级冲突（#117）、DSH 0.2.3+ 图片请求目标字段缺失（#116）、新版 DSH 移除 `assertUsableApiKey` 导致插件启动失败（#111），以及概览页今日 KPI 误用 7 日累计等问题。
- fork 侧多账号轮询在两个入口（控制台概览页、设置弹窗）保持一致，会话内固定账号的行为不变。

## [0.6.0] - 2026-11-18

### Added

- 合入上游 0.4.1 → 0.4.5：
  - 新增侧边栏控制台页（概览 / 用量看板 / 账号 / 模型 / 外观 / 关于），可在设置 → 概览中选择是否显示侧边栏入口，保存动作限定在高级页签；
  - 模型页支持按当前渠道与筛选视图一键「全部开启 / 全部关闭」，单次原子写入，跳过配置缺失的模型（#102）；
  - 额度展示新增「同心嵌套双环」「水位填充胶囊」「双行微进度条」「极简双环」四种样式，并新增「显示边框」开关（`usagePillBorder`）；旧配置中的 `usagePillStyle: 'plain'` 自动映射为无边框徽章；
  - 手绘 `go` 标记用于侧边栏条目与设置页导航。

### Changed

- 发布产物改为跟踪单一预打包归档：仓库根目录保留与 `package.json` 版本一致的 `dsh-opencode-go-<version>.tgz`，由 `npm run pack:release` 生成，`check:pack` 校验它与工作区逐字节一致。
- 多账号轮询开关同时出现在控制台概览页与设置弹窗，行为一致。

### Fixed

- 修复额度胶囊百分比被裁切（#98），并调整字体与暗色/亮色表面层次。

## [0.5.1] - 2026-11-13

### Fixed

- 多账号轮询改为会话内固定账号：同一会话的连续请求留在同一个账号上，复用该账号的提示缓存，只有新会话才轮到列表中的下一个账号。绑定账号真正失败并被换号后，会话跟随新账号，不会下一轮又切回去；账号被临时冷却时只跳过当次请求，冷却结束后回到原账号。设置页提示与文档同步更新。

## [0.5.0] - 2026-11-13

### Added

- 新增 `balanceAccounts` 多账号轮询：开启后每个请求依次从账号列表中的下一个账号开始，几份订阅的额度同时消耗。它只改变每次请求的起点，不写回列表顺序和当前主账号，账号不足两个时保持原顺序；与 `autoSwitch` 相互独立，希望额度耗尽后继续切换时需同时开启。设置页账号卡片新增“多账号轮询”开关，中文与英文文案同步更新。
- 合入上游 0.4.0：四页签设置页（概览 / 模型 / 外观 / 高级）、`appearanceTheme` 主题（Native / Classic）、Free 通道显式 opt-in、`check:pack`、`check:install:pnpm` 与 `check:hygiene` 检查，以及 P1/P2 批次加固。
- 保留本 fork 的本地隐私保护：Go `deepseek-v4.1-flash` 文本秘密遮罩（privacy-guard），默认关闭，发送前替换识别出的秘密，响应和工具参数在本地还原。

## [upstream 0.5.1] - 2026-11-26

### Fixed

- 修复 Go 通道在 SOCKS5 代理地址为 IPv6 字面量（如 `socks5://user:pass@[2001:db8::1]:1080`）时全部请求失败（`network error (ENOTFOUND)`）的问题（#121）：`URL.hostname` 会保留 IPv6 地址的方括号，undici 的 `Socks5ProxyAgent` 将其原样交给连接器，Linux/macOS 的解析器因此拒绝解析。插件现在在连接代理前去掉方括号；Free 通道不受影响。
  - 这是插件侧的过渡修复：上游 nodejs/undici#6243 已修复代理与目标两端，但截至本版发布时尚未发版，后续将 `undici` 升级到包含该修复的版本即可彻底解决（见 `docs/development.md`）。
  - 暂未覆盖：Go 通道经 SOCKS5 代理访问 IPv6 字面量主机的网关地址（如 `http://[::1]:8080/v1`）仍会失败，请将网关地址改用域名或 IPv4 地址，或使用 Free 通道。

### Changed

- 插件包图标放大：`go` 标记由 22px 居中缩小改为直接铺满 36 单位画布，在 DSH 插件列表中与相邻插件大小一致。
- 预打包发布归档更新为 `dsh-opencode-go-0.5.1.tgz`。

## [upstream 0.5.0] - 2026-11-24

跨版本综合体验与工程大升级，围绕功能完整性、交互易用性、设计美观性、信息架构一致性、数据可视化洞察与前端工程健壮性 6 大维度系统重构：

### Added

- **配额月度告警、瓶颈透出与多画像估算**：
  - 对话输入栏用量胶囊在月度额度达到 `≥ 80%` 或触发限流时显式展示月度告警标识，消除「5 小时余量充足但月度已满」的盲区；
  - 弹层剩余调用次数估算明确标注受限瓶颈窗口（`5 小时` / `每周` / `每月`）；
  - 模型详情页「满额预估请求数」支持 3 档使用画像切换（`轻度问答` / `标准编码` / `长上下文 Agent`，超过上下文阈值时自动按阶梯价估算）及套餐档位对比预览。
- **网关连通性安全探测与高级设置增强**：
  - 新增 `opencodeGoModels/probe` Host RPC，在 **高级设置 → 连接** 提供一键「测试连接」，通过无密钥 `/models` 探测当前草稿中的 Go / Free 网关与代理连通性及延迟（绝不发送或回显凭据）；
  - 高级设置毫秒、字节、像素与分钟字段实时展示人类可读换算提示（如 `≈ 5 分钟`、`≈ 20.0 MB`、`≈ 4.2 MP (2048×2048)`），每个字段提供默认值说明、自定义标识、单项恢复默认与字段级精准校验提示；控制台顶部「高级设置」Tab 在存在未保存草稿时显示脏点指示器。
- **模型管理效率与引导升级**：
  - 免费通道未开启时，模型页「免费模型」Tab 渲染专属引导卡与一键开启并自动刷新入口，不再误报“网关无可用模型”；
  - 模型页新增「已开启 / 已关闭」筛选、4 种排序方式（默认 / 额度倍率 / 上下文窗口 / 最新发布）、批量操作受影响计数与一键撤销（Undo）条、容量自动生效 `✓ 已生效` 提示、思考预算快捷预设芯片（`+2K / +4K / +8K / +16K / +32K`）、输入模态三态区分（插件转发 / 上游声明 / 不支持）以及倍率徽标宿主 `<Tooltip>` 升级。
- **账号管理与切号动线重构**：
  - 账号卡片整行可点击展开/收起，支持多行同时展开对比；非首位账号提供一键「设为当前」按钮；添加账号表单内置订阅套餐选择器与 API Key 显隐切换；独立「账号」子页禁用外层折叠防止误收起；
  - 输入栏弹层切号列表异步预览各账号 `5h / 周` 额度占比；侧边栏额度卡清晰区分「预览中」与「生效态」，提供一键「切为当前」与手动刷新按钮。
- **外观双主题 Bento 预览、3×2 实景沙盒与概览 IA 升级**：
  - 外观页重组为「全局界面主题 / 对话输入栏 / 侧边栏与模型选择器」三大分组，升级 Native / Classic 微缩 Bento 主题预览卡，将 5 种胶囊形态扩展为平衡的 3×2 网格（第 6 格提供融合当前形态、边框与高占用/月度告警的「当前实景预览」沙盒），并在 `额度显示 = 关闭` 时对下方样式与边框区域施加因果弱化提示；
  - 概览页移除与页头重复的服务状态胶囊、合并「账号概览」回退链至「当前账号」并支持内联切号、新增 0 账号三步冷启动引导卡与「模型与界面」摘要卡、升级近 7 日柱图为可键盘聚焦与点击固定的交互柱图；统一控制台页头与关于页手绘 `GoRowIcon` 品牌徽章及全插件字体抗锯齿策略；
  - 「关于」页新增一键「复制诊断摘要」（纯前端拼装脱敏 Markdown），并将文档外链修正至 `docs/advanced.md`。
- **用量看板可视化与明细表增强**：
  - 每日趋势图新增第 3 维度「用量金额」，Token 构成图例支持点击隐藏/显示任意序列并动态重算 Y 轴缩放；
  - 模型明细表新增「缓存命中率」列（支持排序）、语义化 `<th scope="col|row">`、粘性首列与横向滚动边缘阴影提示；点击「模型用量分布」行高亮联动定位下方明细行；CSV 导出成功后提供「已导出」反馈；
  - 修正控制台页面模式下双 `<h1>` 无障碍层级问题，历史看板配额重置 Tooltip 同时展示本地时间与 UTC 参考。

### Fixed

- 修复 `ModelsPage` 在 `models.status === 'idle'`（直接进入控制台模型页或修改网关地址后）不触发 `loadModels()` 导致永久假加载的问题。
- 修复 `OverviewPage` 点击「刷新额度」仅刷新时间戳而不更新局部 `quota` 进度条的问题。
- 修复 `AboutPage` `.rowValueMono` 缺失 `.rowValue` 基础类导致 `<dd>` 样式偏移的问题。
- 修复 `AccountsCard` 添加账号表单双 `autoFocus` 导致初始焦点错落到 Key 输入框的问题。
- 修复 `UsagePill` 外部点击 `mousedown` 反向抢占聊天输入框焦点的问题，并补充弹层视口碰撞水平防溢出保护。
- 收敛客户端观察器与请求底座：`useHostScheme()` 升级为模块级单例 `MutationObserver`、`settings-nav-icon` 移除全局 `characterData` 监听避免流式吐字期间高频 DOM 扫描、新增 `usage-store.ts` 客户端短缓存与并发去重，并让 `UsagePill` 复用 `sharedCatalog`；拆分设置页模型 Tab 异常提示点与自定义指示点语义。

### Changed

- 统一术语为「用量金额」，同步更新 `README.md`、`README.en.md` 与 `docs/v0.5.0-optimization-plan.md`。
- 插件包图标由位图 `assets/icon.png` 更换为矢量 `assets/icon.svg`：图形沿用侧边栏与页头同一个手绘 `go` 标记（`GO_ROW_GEOMETRY`），配色与线条粗细向 DSH 内置插件图标看齐（`g` 轮廓与空心棋石为蓝色渐变，实心棋石为绿→青绿渐变）；图标契约测试将该文件钉在同一份几何与色板上，`check:pack` 同时校验清单 `icon` 指向的文件已入包。
- 预打包发布归档更新为 `dsh-opencode-go-0.5.0.tgz`。

## [0.4.9] - 2026-11-24

### Fixed

- 修复会话模型选择器额度倍率插槽 `conversation.input.model.label` 硬编码 `priority: 100` 与其他插件（如 `dsh-provider-qoder`）冲突，以及注册失败时静默吞掉异常的问题（#117）：
  - 将默认让位优先级调整为非整百值 `137`，在保持向低优先级插件让位的同时避免与常见 `100` 优先级撞车；
  - 遇到同优先级占用冲突时自动向后顺延重试（最多 8 次）并输出 `[dsh-opencode-go]` 警告日志；注册仍失败时输出警告日志并安全降级，不影响设置页等其余功能挂载。

### Changed

- 预打包发布归档更新为 `dsh-opencode-go-0.4.9.tgz`。

## [0.4.8] - 2026-11-23

### Fixed

- 兼容 DeepSeek Harness `0.2.3+` 图片请求目标协议（#116）：在 `requestImageTargetFor()` 与 `OpencodeGoAdapter.imageRequestTarget()` 中同时返回 `maxImageBytes`、`imageTargetBytes` 与旧字段 `maxBytes`，修复携带图片附件的会话在 DSH `0.2.3-alpha.2` 及后续版本中因缺少 `maxImageBytes` 触发 `INVALID_ATTACHMENT_REF` 导致每轮失败的问题，同时保持对 DSH `0.2.1` / `0.2.2` 宿主的向后兼容。

### Changed

- 预打包发布归档更新为 `dsh-opencode-go-0.4.8.tgz`。

## [0.4.7] - 2026-11-22

### Added

- 会话模型选择器与模型设置列表实时显示额度消耗倍率：
  - 通过 `conversation.input.model.label` 插槽（让位优先级 `100`）在对话输入框的模型下拉列表右侧显示各 OpenCode Go 模型的实时额度消耗倍率（如 `8.40×`、`0.30×`、免费模型显示 `免费` / `Free`），并在 **设置 → OpenCode Go → 外观** 新增「在会话模型选择器中显示额度倍率」（`showModelMultiplier`，默认开启）开关，关闭时立即释放宿主插槽；
  - **设置 → OpenCode Go → 模型** 与控制台「模型」子页的 Go 模型列表同步展示实时额度消耗倍率，悬停可查看当前套餐档位、峰谷倍率对比、即将生效的调价日期及高上下文阶梯价提示，并按峰谷时段边界精准定时刷新。
- 新增 Go 路由宿主重试策略配置（#112）：
  - `OpencodeGoAdapter` 为 Go 路由暴露 `providerRetryPolicy()`（默认 `mode: 'normal'`、`maxRetries: 5`、`backoff.maxDelayMs: 30000`），开箱即可容纳上游网关常见的 15–18 秒 HTTP 429 `Retry-After` 限流等待；
  - 在 **设置 → OpenCode Go → 高级设置 → 请求重试** 中支持配置重试模式（标准 / 始终）、最大重试次数与最大退避 / `Retry-After` 上限（毫秒），保存后热更新立即生效，无需重启。

### Fixed

- 修复普通 HTTP 429 请求限流被误归类为「额度耗尽（`quota`）」并固定冷却 5 分钟、永久改写主备账号顺序的问题（#113、#114）：
  - `accountFallback()` 将 `RATE_LIMIT` 独立映射为 `'rate-limit'`，用量面板显示专属的「当前账号触发请求限流，已自动切换为：」提示；
  - `gatewayKeyRejectionTtlMs()` 对 `RATE_LIMIT` 优先采用上游 `Retry-After`（`providerRetryAfterMs`，未提供时默认 15 秒，限制在 `[1s, 5m]` 区间内），仅 `QUOTA / AUTH / INVALID_CREDENTIAL` 维持 5 分钟冷却；
  - 当回退原因为瞬时限流（`'rate-limit'`）时，`GoAccountManager.settle()` 仅在冷却期内临时借用备用账号，不再改写已保存的主备账号顺序，冷却结束后自动恢复主账号。
- 修复网关 `cost.multipliers` 中纯生效日期规则（`date`）或尚未生效的复合周期规则被误判为当前日常高峰时段（`Peak`）的问题。

### Changed

- 补充 `README.md`、`README.en.md`、`docs/advanced.md` 与 `docs/advanced.en.md` 中关于 `retryPolicy` 配置项及单账号高并发派发 subagent 触发 429 限流的 FAQ 说明。
- 预打包发布归档更新为 `dsh-opencode-go-0.4.7.tgz`。

## [0.4.6] - 2026-11-20

### Added

- 模型开关界面显示网关价格（#105）：**设置 → OpenCode Go → 模型** 与控制台「模型」子页的每一行都直接显示该模型在 `/models` 中声明的输入 / 输出价格（美元 / 百万 Token）；选中模型的参数卡补充缓存读取 / 写入价格、上下文阶梯费率，并在网关声明时段倍率时注明「部分时段按倍率计价」。网关未公布价格的模型不显示价格，并在卡片中说明；Free 模型显示「免费」。价格仅用于展示，不参与计费、额度或路由判断。
- 智能估算单模型可调用次数与当前剩余次数：支持为每个账号单独配置 Go 套餐档位（`Go ($10)` / `Go Plus ($40)` / `Go Teams ($20)`），在模型详情卡展示三档窗口满额预估请求数，并在对话输入栏用量弹层结合当前选中模型、瓶颈窗口及分时倍率（`峰` / `谷` 徽标）实时显示预估剩余调用次数。

### Fixed

- 修复插件在移除 `@deepseek-ai/dsh-llm` 中 `assertUsableApiKey` 导出的新版 DSH 上启动失败的问题（#111）：改为在插件本地实现同语义的 API Key 格式校验与错误提示，同时兼容 DSH `0.2.1-rc.5`、`0.2.2-rc.5` 及后续版本。
- 修复概览页今日 KPI 误用 7 日累计值的问题，改为按 UTC 今日汇总；优化账号套餐同步、模型列表与详情区独立滚动及切换页签/筛选后的滚动复位体验。

### Changed

- 精简模型参数卡底部说明，移除冗余的容量、输入模态与价格来源脚注，仅在模型声明了图像以外的输入模态时保留附件转发提示。
- 预打包发布归档更新为 `dsh-opencode-go-0.4.6.tgz`。
## [0.4.5] - 2026-11-17

### Added

- 新增输入栏额度展示样式与独立边框开关：在 **设置 → OpenCode Go → 外观** 以及侧边栏控制台的 **外观** 子页中，除原有「徽章（默认）」外，新增「同心嵌套双环（`concentric`）」、「水位填充胶囊（`fill`）」、「双行微进度条（`bars`）」与「极简双环（`rings`）」四种可视化样式，并新增「显示边框（`usagePillBorder`，默认开启）」开关，支持自由组合任意样式与有/无边框效果，所有预览随选项实时更新并即时生效。
- 模型页支持按当前渠道（Go / Free）与当前搜索及筛选视图一键 **全部开启 / 全部关闭**（#102）：
  - 点击「全部开启」或「全部关闭」以单次原子写入更新可见性并立即生效，跳过配置缺失（`configurationMissing`）模型，且「全部开启」同样对过时（`deprecated`）模型生效；
  - 全部已开 / 全部已关、正在保存、只读或当前筛选无可配置模型时自动禁用对应按钮。

### Changed

- 兼容旧版配置中的 `usagePillStyle: 'plain'`：加载与运行时自动映射为无边框的默认徽章（`badge` + `usagePillBorder: false`），并在配置可写时迁移为新字段。
- 补充 `README.md`、`README.en.md`、`docs/advanced.md` 与 `docs/advanced.en.md` 中关于模型目录默认开启行为与批量开关的说明。
- 预打包发布归档更新为 `dsh-opencode-go-0.4.5.tgz`。

## [0.4.4] - 2026-11-15

### Fixed

- 修复对话输入框额度胶囊（`UsagePill`）在部分字体（如衬线体）下末尾百分号 `%` 右侧被轻微裁切的问题（#98）。

### Changed

- 微调面板、看板与弹窗文字字号及亚像素抗锯齿渲染。
- 仓库发布规则更新：根目录同步追踪唯一一个与当前版本一致的预打包归档 `dsh-opencode-go-<version>.tgz`（当前为 `dsh-opencode-go-0.4.4.tgz`），供无法等待 npm 发版的用户（如 DS Bot / DSH 桌面端 / 离线环境）直接手动安装或升级；更新 `.gitignore`（`*.tgz` 保留忽略、仅放行 `/dsh-opencode-go-*.tgz`）与 `.gitattributes`（`*.tgz binary`）。
- 新增 `npm run pack:release`（清理旧版根目录 `.tgz` 并重新打包校验），并将“唯一版本 `.tgz` + 包内文件与工作区逐字节一致”校验接入 `npm run check:pack` 与 CI。
- 更新 `README.md`、`README.en.md`、`docs/advanced.md`、`docs/advanced.en.md`、`docs/development.md` 与 `docs/independent-package.md`，补充 `.tgz` 手动安装、升级、排查与仓库发版说明。

## [0.4.3] - 2026-11-13

### Changed

- 设置对话框左侧导航的「OpenCode Go」行图标改为手绘 go 标记：优先通过宿主 DSH 0.2.2+ 新增的 `settings.section.icon` 图标 seat 注册（普通/选中态跟随宿主文字颜色）；对未声明该 seat 的旧宿主退回 DOM 兜底——按本地化 label 认行、隐藏兜底齿轮、用 CSS mask 画同款图标，宿主 DOM 变化时保留齿轮且不报错。
- 图标几何抽成 `GO_ROW_GEOMETRY` 单一来源：侧栏入口组件与设置导航 mask 共用同一份路径，避免两处图形漂移；新增 `tests/settings-nav-icon.client.spec.tsx`（图标 seat、旧宿主兜底、locale 切换、卸载清理、无 `MutationObserver` 降级）。

## [0.4.2] - 2026-11-13

### Changed

- 侧边栏入口图标改为手绘轮廓的「go」标记：由手绘 `g` 轮廓、实心棋石与空心棋石组成（`GoRowIcon` 独立实现并继承 `currentColor`），16px 展开栏与 18px 收起栏下渲染一致；页面头部、关于页品牌方块（`GoMark` / `GoLogo`）仍保留原波浪标记。
- 新增 `tests/icon.client.spec.tsx` 图标契约测试（24 viewBox、手绘路径与描边、实心/空心棋石、`currentColor`、16/18/24px 尺寸）；侧栏注册测试同时断言入口行使用该图标，避免后续重构回退成旧波形。

## [0.4.1] - 2026-11-13

### Added

- 新增侧边栏控制台入口：通过 `sidebar.panellist` + `main` 槽位在宿主侧边栏（插件市场之后）注册「OpenCode Go」入口行，点击在主内容区打开整页控制台；宿主未声明该槽位时保持原有设置页入口不变，不影响旧宿主。
- 控制台页包含 6 个子页：概览、用量看板、账号、模型、外观、关于。用量看板由原弹窗 `AnalyticsDialog` 抽出为可复用的 `AnalyticsDashboard`（对话输入框用量胶囊与侧栏配额卡的「用量历史」改为跳转页面；没有页面入口的宿主仍回退到原弹窗）。
- 设置页新增「打开完整页面」入口；账号卡片与模型/外观/高级设置拆分为可复用组件（`AccountsCard` / `ModelsSettings` / `AppearanceSettings` / `AdvancedSettings`），设置页与控制台共用同一套控制器，避免双份状态。
- 新增「侧边栏入口」开关（配置项 `sidebarEntry`，默认 `false`）：位于 **设置 → OpenCode Go → 概览**。开启后插件才在宿主侧边栏（插件市场之后）注册入口行与完整控制台页面；默认关闭，安装插件不会自动增加侧边栏条目。旧宿主或未声明 `sidebar.panellist` 槽位的客户端组合保持原有设置页与对话内弹窗入口不变。
- 控制台页「关于」页签显示入口状态：开启时展示 `sidebar.panellist · order 2`，关闭时提示在设置中开启。

### Changed

- **设置改为单一保存手势**：只有「高级设置」保留保存 / 放弃，其余开关与选项（启用、侧边栏入口、免费通道、额度显示、界面主题、侧边栏额度、输入栏额度样式、模型可见性与容量、全部账号操作）在修改时立即写入并生效。高级设置卡新增一行说明，外观、模型容量与可见性等相关提示语同步改写，不再暗示这些页面需要保存；页签上的外观草稿标记随之移除。
- 侧边栏入口与控制台页跟随开关动态注册：关闭开关时先离开页面再注销 `main` + `sidebar.panellist` 这一对槽位，重新开启时再注册。设置页的「打开完整页面」按钮随入口一起出现或消失；对话内用量胶囊在页面不可用时回退到内置用量历史弹窗。
- 控制台概览页的服务状态卡在免费通道写入被拒绝时显示即时失败提示（`immediateWriteFailed`）；页面底部的保存条只对高级设置草稿出现（`dirty || failed`），不再为其他页面的即时修改出现。
- 设置页底部操作条统一高度：保存 / 放弃只出现在高级设置页签，其余页签保留同样的 `size="md"` 控件行高度（36px），切换页签时面板与滚动区高度不再跳动。

### Fixed

- 修复第三方外壳（如 DS Bot 0.3.2 设置面板）不向设置节传递确定高度时，`dsh-opencode-go` 设置页高度塌陷、四个页签与内容被裁成一条的问题（#94）：页面容器查询改为仅约束行内尺寸，滚动主体在页面高度由内容决定时按内容高度展开；在 DSH 官方设置面板中布局、滚动与宽度断点行为保持不变。

## [0.4.0] - 2026-11-10

### Added

- 新增 `appearanceTheme` 界面主题设置（`native` / `classic`），默认 `native`；未设置该字段的旧配置缺省使用 Native。
- 新增 `npm run check:install:pnpm`：用 pnpm 11.28.5 在隔离 consumer 中安装实际 tarball，禁用已有构建批准并启用严格构建失败策略，同时验证匹配平台的 Bun 二进制可以执行；CI 以非 advisory job 运行该安装检查。
- 测试加固：全量 Vitest 测试套件扩展至 21 个文件 / 1075 个测试用例。

### Changed

- 版本号提升到 `0.4.0`：新增 Native / Classic 主题选择，输入栏额度弹层与设置页全方位紧凑布局改版，并收录 0.3.0 之后的安装、兼容性与 Gemini 工具历史修复。
- **输入栏额度弹层改版**：标题行右侧合并当前账号入口（点击进入账号切换）；三档额度改为「标签 · 重置时间 · 百分比」一行 + 通栏进度条；底部合并为「用量历史 ｜ 更新于 ｜ 刷新额度」操作条。352px 宽、双账号下实测高度由约 434px 降至约 244px；显式声明 `line-height`，消除单行文本被撑高一倍的隐性高度；所有时间戳统一显示到分钟。
- **设置页改为顶部分页与紧凑结构**：顶部四个页签（概览 / 模型 / 外观 / 高级）在内容滚动时保持固定（`position: sticky`）；删除页面说明行与模型 / 外观 / 高级设置三个子页重复的标题，「恢复默认外观」「重置参数」移至各卡片底部；概览的两个开关文案收窄为「启用 OpenCode Go」与「免费通道」，与账号摘要整合为统一行距的列表；模型页列表与参数框限高整体收敛至 448px；四大页签顶部起始间距对齐。
- **账号区改为紧凑两行**：第一行状态点 + 名称 + Key 状态 + 百分比 + 展开箭头，第二行通栏额度条 + 重置倒计时；去掉每行的大圆角描边盒子，行间只用发丝线；添加账号与自动切换合并到底部一行，拖动把手改为悬停显示（键盘仍可直接聚焦）。
- 设置页、用量胶囊、侧栏与历史看板共用布局和内部主题 token：Native 通过 Host 公开语义 token 跟随 DSH 与第三方主题的颜色、字体、圆角等，无法解析时使用中性 fallback；Classic 保留暖纸 / 炭灰、陶土色与衬线风格，不跟随 Host 或第三方主题覆盖这些品牌 token。
- 主题切换不再改变组件布局；样式边界收敛到插件自有组件与共享 token 层，移除对宿主私有样式的越界覆盖。输入栏 `badge` / `plain` 样式及侧栏额度设置行为不变。

### Fixed

- 修复 Gemini 3+ / 4 在旧会话或缺少回放元数据时，历史 `functionCall` 因没有 `thoughtSignature` 而被上游以 HTTP 400 拒绝的问题（#90）。真实签名及带签名的并行工具调用保持原样；完全无签名的工具轮次使用 Google 兼容占位标记跳过校验。
- 修复评审问题：历史看板额度重置提示恢复 UTC 日期与时间；账户列表在 `readUsage` 未返回时即发布 `configured / loading` 状态（未配置 Key 不再等待所有网络读取），各账户读取完成后逐行更新；Google SDK 懒加载失败后不再永久缓存 rejected Promise；`GoAccountManager.capture()` 继续避免热路径调用 `settings.describe()`，同时通过 `settings/document-updated` 事件围栏外部 `A -> C -> A` 编辑，过期的回退结算会被拒绝（新增回归测试）。
- 修复设置页额度进度条在 Native 浅色主题下不可见：轨道原本使用宿主 `layer-2` 表面色，默认 Native 浅色下与卡片同为白色（约 1.0:1，中性 fallback 也只有约 1.1:1），1% 等小幅值时只剩一小段填充，像散落的色块。现统一为派生 `--go-track`（主题文字色 18% 混入背景），设置页行内额度条与展开的三档额度条、用量弹层、侧栏和历史看板的额度条与模型占比条共用；轨道在浅色下约 1.4:1、深色下约 1.7:1，受检的 Native/Classic fallback 调色板中填充与轨道保持 ≥2.5:1 可分辨（Native accent 会跟随 Host，第三方主题 accent 不在该断言范围内），`theme.client.spec.ts` 新增轨道可见性与样式表漂移断言。同时去掉行内额度条原有的 25% / 50% / 75% 白色刻度：轨道不可见时它们也看不见，轨道可见后却把整条切成了四段。
- 修复 Native 主题的对比度回退：强控件边界（`borderStrong`）与图表状态系列（`accent2` / `cacheRead` / `cacheWrite`）不再映射 Host 的 `border-l2` 发丝线与 `state-*` 状态点色（它们不保证控件边界与图表所需的非文本对比度），改为使用插件受控静态值，恢复 WCAG 1.4.11 3:1；`theme.client.spec.ts` 新增对 Host 实际表面范围（浅色白、深色 `#151517` / `#232324` / `#2c2c2e`）的断言，防止默认主题再次静默回退。
- Free 运行时改为直接声明版本锁定的官方 `@oven/bun-*` 可选平台包，移除带 `postinstall` 的 `bun` 包装依赖，修复 pnpm 11 在未批准构建脚本时安装或升级失败并回滚的问题（#87）。平台运行时仍会下载；Go 与现有 `MISSING_BUN_RUNTIME` 降级语义不变。
- 修复 Free 凭据绑定：官方 host 分支现在同时要求 `https:` 与默认端口，`http://opencode.ai` 与 `https://opencode.ai:8443` 不再复用已保存的付费 Key，改为匿名 `Bearer public`，避免明文或非官方监听路径收到账号凭据（其它自定义 host 原本就不复用）。
- 修复 SOCKS 中继空闲上限短于流空闲预算的问题：中继上限改由请求的 `streamIdleTimeoutMs` 派生并保留 30 秒余量（默认 330 秒，原为固定 120 秒），`FreeBunTransport.forProxy` 透传该预算，使排队或大上下文 prefill 期间的静默先由插件自身判定为 `LLM_STREAM_IDLE_TIMEOUT`，而不是被中继拆连后归为 `NETWORK` 并触发 Free 冷却。
- 修复 Classic 浅色图表的实绘对比度：`cacheWrite` 在三个浅色表面上、`cacheRead` 在 `surface2` 上按柱体 88% 不透明度合成后低于 WCAG 1.4.11 3:1，分别调整为 `#787c6b` / `#8a7766`；柱体不透明度发布为 `--go-chart-bar-opacity` token，主题测试在原有原始 token 断言之外增加按合成后实际颜色的断言。
- 「切换账号」列表行高 44 → 38px 并增加上下留白；选中态改用不透明 `--go-accent-soft` 底色并叠加 1px 内描边，分隔线左右内缩，修复半透明底色导致的圆角发灰与圆角贴线问题。
- 修复分页后卡片顶部出现多余浅色分隔线的问题；同时清零卡片标题（h3 默认外边距）并收紧页头/页签间距，减少外观 / 模型 / 高级页的空白。
- 修复模型页左侧列表无法独立滚动：分页面板恢复为纵向 flex 容器，模型卡片重新获得剩余高度，左侧列表与右侧参数面板各自滚动。

## [0.3.0] - 2026-11-07

### Added

- Free 通道（`dsh-opencode-free`）改为**显式 opt-in**：新增 `freeEnabled` 设置并默认关闭；未开启时不注册 Free 路由、不拉取 Free 目录、不在模型发现与设置页暴露 Free 模型，关闭开关并保存后撤回路由且允许进行中的请求完成。
- 用量看板图表补充键盘行为：Escape 仅在存在已固定/激活日期时消费，否则保留宿主弹窗的关闭行为。
- 发布防护：新增 `scripts/check-pack.mjs` 与 `npm run check:pack`，断言 npm tarball 包含运行期、类型、文档与第三方通知所需文件；CI 的 `core` job 增加该步骤。
- `lib/build-info.json` 记录包版本；tarball 随包发布 `scripts/licenses/pi-1.5.0-LICENSE`，使 `THIRD_PARTY_NOTICES.md` 的引用在安装包内可解析。
- 仓库新增 `CHANGELOG.md` 与 `SECURITY.md`；CI 新增 advisory 兼容 job，在临时 consumer 中对 DSH `0.2.2-rc.1` 的 Host 路径运行 installed-package 冒烟（允许失败）。
- 本批新增 65 个回归测试。
- 发布内容：`CHANGELOG.md` 与 `SECURITY.md` 纳入 npm tarball，`check:pack` 同步断言。
- 仓库卫生：删除未被引用的跟踪资产（根目录 `image.png`、`.github/assets/*.png`）；新增 `npm run check:hygiene`（`scripts/check-source.mjs`），检查跟踪源文件的 BOM/LF/行尾空白/文件末尾单换行，并要求 `src`/`scripts` 无 tab，已接入 `verify` 链。

### Changed

- 版本号提升到 `0.3.0`：本次包含破坏性行为变化（Free 默认关闭、peer 依赖调整、Free worker 环境 allowlist）。
- devDependencies 评估后**不裁剪**：DSH 客户端包（如 `@deepseek-ai/dsh-client-ui-primitives`、`@deepseek-ai/dsh-client-store`）在运行期直接 import 了一部分未写进其自身清单的依赖（`clsx`、`shiki`/`@shikijs/langs`、`katex`、markdown/micromark 链、`zustand`/`immer`、`simple-icons`、`@deepseek-ai/dsh-util-workspace-path` 等），根 `devDependencies` 是这些隐式运行期与类型依赖的唯一供给，因此保留原有 devDependencies 不变；CI 的干净 `npm ci` 是唯一可靠验证。
- 依赖：`@deepseek-ai/dsh-brand` 与 `@deepseek-ai/schemastery` 从 `dependencies` 调整为宿主提供的 `peerDependencies`（`>=0.2.1-rc.5` / `>=3.18.5 <4`），避免 profile 内重复安装；Cordis peer 范围由 `~4.0.5` 放宽为 `^4.0.5`，覆盖 DSH 0.2.2 携带的 Cordis 4.1.0。
- Free Bun worker 改为使用显式环境 allowlist，不再继承 `process.env`：`NODE_EXTRA_CA_CERTS`、`NODE_TLS_REJECT_UNAUTHORIZED`、`NODE_OPTIONS`、`LD_PRELOAD`/`DYLD_INSERT_LIBRARIES` 与代理变量不再跨进程传递。
- 请求生命周期：插件卸载时释放两条路由的 adapter；adapter 不再 dispose 注入的共享 `ProxyTransport`，Free worker 与 SOCKS 隧道因此有回收路径，同时不破坏 Host 拥有的传输。
- `LlmFailure` 从实际 HTTP 响应与 `Retry-After` 回填 `status` / `providerRetryAfterMs`；实现 `imageRequestTarget`，使 token meter 按实际序列化的图片计价。
- 官方历史 CSV 容忍空行与多余尾列；`cost_usd` 仅用于展示，`cost_micro_cents` 继续精确汇总。
- 模型目录 discovery 拒绝重定向并脱敏失败 URL；Host 与浏览器设置表单均拒绝内嵌凭据的 `baseURL`。
- thinking budgets 的非法值改为过滤/钳制，不再使模型解析整体失败；浏览器与 Host 共享 `MAX_THINKING_BUDGET_TOKENS`。
- 客户端：移除未使用的 inject 服务，区分加载中与不可用，数值输入与 Host 边界一致（字段级错误、`min` / `max` / `step`），并区分 provider 切换失败与模型可见性失败。
- Free IPC 边界：请求体在读入前按 `Content-Length`、读入后按真实字节数受 64 MiB 上限保护；worker 在 `JSON.parse` 前对 stdin 累计 256 MiB 上限做检查。
- 发布流程：`prepack` 重新执行 `check:dist`，`prepublishOnly` 执行类型检查与 `test:ci`，避免陈旧 `lib/` 被发布；`scripts/headless-smoke.mjs` 现在要求显式传入 consumer 参数（缺省打印用法并以退出码 2 结束）。
- 文档：`x-opencode-session` 措辞精确化为“常见可打印 ASCII 会话 ID 原样透传，仅非常规/保留前缀 ID 做 sha256 + base64url”；补充 Bun 可选依赖 postinstall 行为、发布检查说明与验证矩阵。

### Fixed

- 官方 CSV 遇到空行或额外尾列时会解析失败。
- discovery 跟随重定向、错误信息携带目录 URL、`baseURL` 内嵌凭据等诊断与凭据问题。
- 非法 thinking budget 导致模型解析失败。
- 插件卸载后 Free Bun worker 与 SOCKS 隧道缺少释放路径。

## [0.2.1] - 2026-11-06

### Added

- 官方 Console 每日 CSV 历史用量看板：按所选 Key 的工作区汇总，provider + model 分组，UTC 日序列补零，`cost_micro_cents` 精确汇总，并明确官方用量口径与隐私边界。
- 侧栏月额度与账号预览：三个额度窗口常驻展示，账号徽标可循环查看只读额度并记住查看账号，不可用读数明确报错。
- Go 与平台 Free 双路由动态模型目录：分别从各自 `/models` 发现模型与价格，保留同名模型，路由级开关与容量设置独立；内置 pi-ai 升级到 1.5.0。
- 统一 Claude 风格的插件接口，并紧凑化模型设置布局。

### Changed

- 历史看板从本地统计切换为官方 Console 每日 CSV 数据源。
- 模型与价格元数据改由各网关 `/models` 声明提供，不再依赖 models.dev 刷新。
- Free 限流处理移入插件内部；对外错误分类保持 `FREE_QUOTA`、`FREE_RATE_LIMIT` 等稳定语义。
- 改进 Free 传输、额度 UI 与 token 预算。

### Fixed

- 上下文变化后，回放用量不再沿用旧值。
- CI 兼容 npm 10 与 Windows 权限设置。
- POSIX 上接受 Bun 启动器路径。
